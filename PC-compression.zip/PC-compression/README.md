All HCLT experiments are in PC-learning-and-compression/

All PC+IDF experiments are in PC+IDF/