To run the experiment: python3 main.py

Need to download and extract files from Imagenet64_train_npz and Imagenet64_val_npz, and change the data path in lines 70 and 71 of prep_idf.py