using LogicCircuits
using ProbabilisticCircuits


function decompress_data(pbc::CompressParamBitCircuit, code, values = nothing, target_data = nothing, 
                         reuse = (nothing, nothing, nothing, nothing, nothing, nothing, nothing, nothing); 
                         Float = Float64, ll_interval::Integer = 5)
    num_vars = maximum(pbc.lit_to_var)
    num_cats = size(pbc.cat_params, 2)
    
    decompress_marginal(pbc, code, values, target_data, reuse; num_vars, num_cats, Float, ll_interval)
end