

function get_code_length(code::Matrix{UInt64})
    code_lengths = Vector{UInt64}(undef, size(code, 1))
    for i = 1 : size(code, 1)
        code_lengths[i] = UInt64(0)
        for j = 1 : size(code, 2)
            c = @inbounds code[i, j]
            c = (c >> 1)
            while c > UInt64(1)
                c = (c >> 1)
                code_lengths[i] += 1
            end
        end
    end
    code_lengths
end