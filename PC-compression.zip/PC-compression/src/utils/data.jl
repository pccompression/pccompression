using LogicCircuits
using ProbabilisticCircuits
using CUDA


import ProbabilisticCircuits: to_gpu, to_cpu

to_gpu(v::Vector{Union{UInt32,Missing}}) =
    CuArray(UInt32.(coalesce.(v, typemax(UInt32))))

to_gpu(v::Matrix{Union{UInt32,Missing}}) =
    CuMatrix(UInt32.(coalesce.(v, typemax(UInt32))))

to_cpu(v::CuVector{UInt32}) =
    convert(Vector{Union{UInt32,Missing}}, 
        replace(Array(v), typemax(UInt32) => missing))

import ProbabilisticCircuits: num_examples

num_examples(v::Matrix{UInt32}) = size(v, 1)
num_examples(v::CuArray{UInt32, 2}) = size(v, 1)