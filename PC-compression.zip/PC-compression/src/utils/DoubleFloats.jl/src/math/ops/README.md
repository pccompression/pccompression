acronym | meaning
--------|--------
op | operator (`abs`, `neg`, `negabs`, `add`, `sub`, `mul`, `dvi`, `root2`)
fp | floating point (`Float64`, `Float32`, `Float16`)
dd | DoubleFloat as a 2-tuple (hi, lo)
db | DoubleFloat as a struct DoubleFloat{::IEEEFloat}(hi, lo)
