using CUDA


function find_gpu_device()
    gpu_idx = 0
    max_available_mem = 0.0
    for (gpu, dev) in enumerate(devices())
        device!(dev)
        available_mem = CUDA.available_memory()
        if available_mem > max_available_mem
            gpu_idx = gpu
            max_available_mem = available_mem
        end
    end
    
    gpu_idx
end


function select_gpu_device()
    gpu_idx = find_gpu_device()
    device!(collect(devices())[gpu_idx])
end