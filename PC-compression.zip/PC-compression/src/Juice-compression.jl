using LogicCircuits
using ProbabilisticCircuits

include("utils/data.jl")

include("categorical_leafs/node.jl")
include("categorical_leafs/bit_circuit.jl")
include("categorical_leafs/param_bit_circuit.jl")
include("categorical_leafs/cat_marginal_flows.jl")
include("categorical_leafs/cat_sgd_flows.jl")
include("categorical_leafs/marginal_queries.jl")
include("categorical_leafs/parameters.jl")

include("structures/hclt.jl")
include("structures/dhclt.jl")
include("structures/clt.jl")

include("train/em.jl")

include("utils/circuit_io.jl")
include("utils/DoubleFloats.jl/src/DoubleFloats.jl")

include("transformations/prune.jl")
include("transformations/convert.jl")

include("compress/utils.jl")
include("compress/basic_queries.jl")
include("compress/compressor_bit_circuit.jl")
include("compress/compressor_param_bit_circuit.jl")
include("compress/compress_marginal.jl")
include("compress/compress.jl")
include("compress/decompress_marginal.jl")
include("compress/decompress.jl")

include("compress/compress_rANS.jl")
include("compress/decompress_rANS.jl")